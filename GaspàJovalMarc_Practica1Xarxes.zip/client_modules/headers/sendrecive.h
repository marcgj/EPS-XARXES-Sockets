#ifndef XARXES_PRACTICA1_SENDRECIVE_H
#define XARXES_PRACTICA1_SENDRECIVE_H

#include "config.h"

void send_element(Element elem);

void handle_incoming_connection(int sock);

#endif //XARXES_PRACTICA1_SENDRECIVE_H
