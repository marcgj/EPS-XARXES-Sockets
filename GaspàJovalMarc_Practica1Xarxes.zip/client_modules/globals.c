#include "headers/globals.h"

/*
 * Totes les variables globals es troben en aquest archiu
 */

int debug = 0;
unsigned char status = NOT_REGISTERED;
ClientCfg cfg;
ConnexionInfo srv_info;
int udpSocket;
int tcpSock;
int end = 0;
